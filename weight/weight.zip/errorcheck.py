#!/usr/bin/python

def list_to_int(list):
        new_list = []
        for str in list:
                new_list.append(int(str))
        list = new_list
        return list

def error_check(file_name):
        f = open(file_name, 'r')
        n = open(file_name + '.errorlog', 'w')
        x_row = []
        y_row = []

        for row in f:
                row = row.split()
                x_row.append(row[0])
                y_row.append(row[1])

        x_row = list_to_int(x_row)
        y_row = list_to_int(y_row)
    
        print 'Sorted x list:'
        print sorted(x_row)
        print 'Sorted y list:'
        print sorted(y_row)

        print 'Min x number:', min(x_row)
        print 'Max x number:', max(x_row)
        print 'Min y number:', min(y_row)
        print 'Max y number:', max(y_row)

        print 'Beginning error checking...'

        print 'Checking x values...'
        are_errors = False
        for x in range(min(x_row), max(x_row)+1):
                if x_row.count(x) == 0:
                        warning = 'Warning! Empty at x = ' + str(x)
                        print warning
                        n.write(warning + '\n')
                        are_errors = True

        if are_errors == False:
                print 'No errors found.'
    
        print 'Checking y values...'
        for y in range(min(y_row), max(y_row)+1):
                if y_row.count(y) == 0:
                        warning = 'Warning! Empty at y = ' + str(y)
                        print warning
                        n.write(warning + '\n')
                        are_errors = True

        if are_errors == False:
                print 'No errors found.'

        n.close()
        f.close()
        return
